""" 2021.11.22. """

import code

# code.feladat1()
# code.feladat2(50, 70, 55)
# code.feladat3()
# code.feladat13(code.lista3)
# code.feladat13_v2(code.lista5)
# code.atlag(code.lista6, 5)
# code.osszefuzes(code.lista5)
# code.megszamlal()