import random

# Globális változó
lista2 = []
for i in range(10):
    lista2.append(random.randint(10, 100))
print(f"Véletlen lista: {lista2}")
lista3 = [23, 56, 7]
lista4 = ["Krumpli", "Kecske", "Sajt"]
lista5 = ["Krumpli", "Kecske", "Sajt", "Alma"]
lista6 = [1, 3, 4, 2, 2, 5, 5, 1]

''' def feladat1():
    jovedelem = 0
    csalad = 0
    for i in range(1, 11):
        jovedelem = random.randrange(20000, 3000000)
        print(jovedelem, end = " ")
        if(jovedelem <= 500000):
            csalad = csalad + 1
    print(f"\nEnnyi családnak van 500 000 Ft alatti jövedelme: {csalad}") '''

''' def feladat2():
    versenyzok = 20
    db = 0
    for i in range(1, 21):
        r = random.randrange(50, 71)
        print(r, end = " ")
        if(r < 60): db = db + 1
    szazalek = (db / versenyzok) * 100
    print(f"\nEnnyien teljesítették a 100 méteres távot egy perc alatt: {szazalek}%") '''

def feladat2(alsoHatar = 50, felsoHatar = 70, szint = 60):
    db = 0
    lista = []
    for i in range(20):
        lista.append(random.randint(alsoHatar, felsoHatar))
    print(f"Az eredmények másodpercben: {lista}")
    for i in range(len(lista)):
        if(lista[i] < szint):
            db = db + 1
    print(f"A szintidőt teljesítők száma: {db}, százalékban kifejezve: {db / len(lista): .2%}")

def feladat3():
    osszeg = 0
    for i in range(1, 6):
        szam = int(input("Kérek egy egész számot: "))
        osszeg = osszeg + szam
    print(f"A bekért számok összege: {osszeg}")

# Maximum kiválasztás tétel
def feladat13(lista):
    maximum = lista[0] # >> Első elem megjegyzése
    for i in range(1, len(lista)):
        if(lista[i] > maximum):
            maximum = lista[i]
    print(f"A legnagyobb eleme a listának: {maximum}")

# az ABC-ben a legelső nevet írasd ki
def feladat13_v2(lista):
    legelso = lista[0] # >> Első elem megjegyzése
    for i in range(1, len(lista)):
        if(lista[i] < legelso):
            legelso = lista[i]
    print(f"A legelső elem neve az ABC-ben: {legelso}")

def atlag(lista, tizedesjegy):
    osszeg = 0
    for i in range(len(lista)):
        osszeg = osszeg + 1
    print(f"A lista átlaga: {osszeg / len(lista): .{tizedesjegy}f}")

def osszefuzes(lista):
    mondat = ""
    for i in range(len(lista)):
        mondat = mondat + lista[i] + "*"
    print(f"Az összefűzött elem: {mondat[:-1]}")

def megszamlal():
    db = 0
    for i in range(10, 100):
        if(i % 4 == 0):
            db = db + 1
    print(f"A 4-gyel osztható kétjegyű számok száma: {db}")