"""
Gyakorlás
"""

# 1. feladat: Írasd ki egy bekért szám faktoriálisának az eredményét!
def feladat1():
    szam1 = int(input("Kérek egy egész számot: "))
    eredmeny1 = 1
    if (szam1 < 0):
        print("Nem értelmezhető!")
    else:
        for i in range(1, szam1 + 1):
            eredmeny1 *= i # eredmeny1 = eredmeny1 * i
        print("A", szam1, "faktoriális eredménye:", eredmeny1)

# 2. feladat: Írjuk 0-tól 150-ig a páros számokat!
def feladat2_a():
    for i in range(0, 151):
        if (i % 2 == 0):
            print(i, end = " ")

def feladat2_b():
    for i in range(0, 151, 2):
        print(i, end = " ")

# 3. feladat: Számold meg 2 bekért szám közötti páratlan számokat!
def feladat3():
    szam31 = int(input("Kérek egy egész számot: "))
    szam32 = int(input("Kérek egy másik egész számot: "))
    db3 = 0
    if (szam31 < szam32):
        for i in range(szam31, szam32 + 1):
            if (i % 2 == 1):
                db3 += 1
    elif (szam31 >= szam32):
        for i in range(szam32, szam31 + 1):
            if (i % 2 == 1):
                db3 += 1
    print("A páratlan számok darabszáma:", db3)

# 5. feladat: Kérj be 5 számot és add össze őket!
def feladat5():
    osszeg5 = 0
    for i in range(5):
        szam5 = int(input("Kérek egy számot: "))
        """ osszeg5 += szam """
        osszeg5 += szam5
    print("A számok összege:", osszeg5)

# 8. feladat: Kérj be 5 pozitív számot, és írasd ki a legnagyobbat!
def feladat8_a():
    maximum8 = int(input("Kérek egy pozitív számot: "))
    for i in range(4):
        bekert8 = int(input("Kérek egy pozitív számot: "))
        if (maximum8 < bekert8):
            maximum8 = bekert8
    print("A legnagyobb szám:", maximum8)

def feladat8_b():
    maximum8 = 0
    for i in range(5):
        bekert8 = int(input("Kérek egy pozitív számot: "))
        if (maximum8 < bekert8):
            maximum8 = bekert8
    print("A legnagyobb szám:", maximum8)

# 10. feladat: Írjuk ki a számokat 100-tól 1-ig, egy sorba csak tíz szám kerülhet!
def feladat10():
    for i in range(100, 0, -1):
        if (i % 10 == 1):
            print(i)
        else:
            print(i, end = " ")

# 11. feladat: Írjuk ki a számokat 100-tól 1-ig, egy sorba csak hét szám kerülhet!
def feladat11_a():
    for i in range(100, 0, -1):
        if (i % 7 == 3):
            print(i)
        else:
            print(i, end = " ")

def feladat11_b():
    szamlalo = 0
    for i in range(100, 0, -1):
        szamlalo += 1
        if (szamlalo % 7 == 0):
            print(i)
        else:
            print(i, end = " ")

# Önálló feladatok
# 4. feladat: Számold meg 10 bekért szám esetében a 3-mal osztható számokat!
def feladat4():
    darab = 0
    for i in range(10):
        szam = int(input("Kérek egy egész számot: "))
        if (szam % 3 == 0):
            darab = darab + 1
    print("A hárommal osztható számok darabszáma:", darab)

# 6. feladat: Kérj be 5 szöveget, és fűzd őket össze space-szel, majd írasd ki a kész szöveget!
def feladat6():
    szovegossze = ""
    for i in range(5):
        szoveg = input("Kérek egy szöveget: ")
        szovegossze = szovegossze + szoveg + " "
    print(szovegossze)

# 7. feladat: Add össze 10 bekért számnál a negatív számokat!
def feladat7():
    osszeg = 0
    for i in range(10):
        szam = int(input("Kérek egy egész számot: "))
        if (szam < 0):
            osszeg = osszeg + szam
    print("A negatv számok összege: ", osszeg)

# 9. feladat: Kérj be 5 pozitív számot, és írasd ki a legkisebbet!
def feladat9():
    minimum = int(input("Kérek egy egész számot: "))
    for i in range(4):
        bekert = int(input("Kérek egy egész számot: "))
        if (minimum > bekert):
            minimum = bekert
    print("A legkisebb szám: ", minimum)

# 12. feladat: Írjuk ki 0-tól 150-ig a négyzetszámokat!
def feladat12():
    for i in range(0, 151, 1):
        negyzetszam = i * i
        print(negyzetszam, end = " ")

# 13. feladat: Írjuk ki egy bekért pozitív szám valódi osztóit! Ha nincs, írjuk ki, hogy prímszám!
def feladat13():
    bekert = int(input("Kérek egy pozitív egész számot: "))
    for i in range(1, bekert + 1):
        if (bekert % i == 0 and bekert / i != 1 and bekert / i != bekert):
            print("A bekért szám osztói:", i)
        else:
            print("Ez egy prímszám.")
            break

