import metodus_orai_20211011 as metodus

# metodus.feladat1()
# metodus.feladat2_a()
# metodus.feladat2_b()
# metodus.feladat3()
# metodus.feladat8_a()
# metodus.feladat8_b()
# metodus.feladat10()
# metodus.feladat11_a()
# metodus.feladat11_b()

# metodus.feladat4()
# metodus.feladat6()
# metodus.feladat7()
# metodus.feladat12()
metodus.feladat6()